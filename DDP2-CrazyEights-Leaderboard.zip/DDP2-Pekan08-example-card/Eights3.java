public class Eights3 extends Eights{

    private Player player0, player1, player2;

    Eights3(){
        super();
        Deck deck = new Deck("Deck");
        deck.shuffle();

        player0 = new Player("Amir");
        deck.deal(player0.getHand(), 5);
        player1 = new Player("Budi");
        deck.deal(player1.getHand(), 5);
        player2 = new Player("Cepi");
        deck.deal(player2.getHand(), 5);

        // turn one card face up
        discardPile = new Hand("Discards");
        deck.deal(discardPile, 1);

        // put the rest of the deck face down
        drawPile = new Hand("Draw pile");
        deck.dealAll(drawPile);
    }

    /**
     * Switches players.
     */
    public Player nextPlayer(Player current) {
        // Bisa anda buat lebih baik lagi implementasinya?
        // Bayangkan bila player nya ada banyak, apakah kita akan buat 
        // if-else terus menerus?
        
        if (current == player0) {
            return player1;
        }
        if (current == player1) {
            return player2;
        } else {
            return player0;
        }
    }
    /**
     * Plays the game.
     */
    public void playGame() {
        Player player = player0;

        // keep playing until there's a winner
        while (!isDone()) {
            displayState();
            takeTurn(player);
            player = nextPlayer(player);
            in.nextLine();  // wait for enter 
        }

        // display the final score
        player0.displayScore();
        player1.displayScore();
        player2.displayScore();
    }
    /**
     * Returns true if either hand is empty.
     */
    public boolean isDone() {
        return player0.getHand().isEmpty() 
            || player1.getHand().isEmpty()
            || player2.getHand().isEmpty();
    }


    /**
     * Displays the state of the game.
     */
    public void displayState() {
        player0.display();
        player1.display();
        player2.display();
        discardPile.display();
        System.out.println("Draw pile: " + drawPile.size() + " cards");
    }

    /**
     * Creates the game and runs it.
     */
    public static void main(String[] args) {
        Eights3 game = new Eights3();
        game.playGame();
    }

}
