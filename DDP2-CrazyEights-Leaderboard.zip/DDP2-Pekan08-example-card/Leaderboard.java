
import java.util.*;

public class Leaderboard {
    private List<Player> players;

    public Leaderboard(List<Player> players) {
        this.players = new ArrayList<>(players);
    }

    public void printLeaderboard() {
        System.out.println("== LEADERBOARD ==");
        // Sort descending by score
        players.sort((p1, p2) -> Integer.compare(p2.getScore(), p1.getScore()));
        int rank = 1;
        for (Player p : players) {
            System.out.println(rank + ". " + p.getName() + " with scores : " + (p.getScore() >= 0 ? "+" : "") + p.getScore());
            rank++;
        }
    }
}
