
public class EightsMultiplayer extends Eights{

    private Player[] players;
    
    /**
     * Initializes the state of the game.
     */
    public EightsMultiplayer(int playerSize, String[] playerName) {
        Deck deck = new Deck("Deck");
        deck.shuffle();
        players = new Player[playerSize];
        // deal cards to each player
        for (int i=0;i<playerSize;i++){
            players[i] = new Player(playerName[i]);
            deck.deal(players[i].getHand(), 5);
        }
        // turn one card face up
        discardPile = new Hand("Discards");
        deck.deal(discardPile, 1);

        // put the rest of the deck face down
        drawPile = new Hand("Draw pile");
        deck.dealAll(drawPile);

    }

    /**
     * Returns true if either hand is empty.
     */
    public boolean isDone() {
        for (Player player : players){
            if (player.getHand().isEmpty()){ 
                return true;
            }
        }
        return false;
    }

    /**
     * Switches players.
     */
    public Player nextPlayer(Player current) {
        for(int i=0;i<players.length;i++){
            if (players[i]==current)
                return players[(i+1)%players.length];
        }       
        return null;
    }

    /**
     * Displays the state of the game.
     */
    public void displayState() {
        for (Player player : players){
            player.display();
        }
        
        discardPile.display();
        System.out.println("Draw pile: " + drawPile.size() + " cards"); 
    }


    /**
     * Plays the game.
     */
    public void playGame() {
        Player player = players[0];

        // keep playing until there's a winner
        while (!isDone()) {
            displayState();
            takeTurn(player);
            player = nextPlayer(player);
            in.nextLine();  // wait for enter 
        }

        // display the final score
        for (Player player_ : players){
            player_.displayScore();
        }
    }

    /**
     * Creates the game and runs it.
     */
    public static void main(String[] args) {
        EightsMultiplayer game = new EightsMultiplayer(5, new String[]{"Amir","Budi","Cepi","Dudi","Emon"});
        game.playGame();
    }

}



