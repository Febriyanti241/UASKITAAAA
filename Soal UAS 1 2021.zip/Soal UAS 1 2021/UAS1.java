public class UAS1 {
    public static void main(String[] args) {

        // MataKuliah(String namaMataKuliah, String kodeMataKuliah, int sksMataKuliah)
        MataKuliah mk1 = new MataKuliah("Dasar-dasar Pemrograman 2", "CSGE601021", 4);
        MataKuliah mk2 = new MataKuliah("Matematika Diskret 2", "CSGE601011", 3);
        MataKuliah mk3 = new MataKuliah("Aljabar Linier", "CSGE602012", 3);
        
        Mahasiswa mhs1 = new Mahasiswa("Burhan", "1234567890");
        Mahasiswa mhs2 = new Mahasiswa("Burung Hantu", "1234567891");
        Mahasiswa mhs3 = new Mahasiswa("Kak BurHan", "1234567892");
        Mahasiswa mhs4 = new Mahasiswa("Dek DePe", "1234567893");
        Mahasiswa mhs5 = new Mahasiswa("Bang PeWe", "1234567894");

       mhs1.tambahMatkul(mk1);
       
       mhs2.tambahMatkul(mk1);
       mhs2.tambahMatkul(mk2);

       mhs3.tambahMatkul(mk1);
       mhs3.tambahMatkul(mk2);
       mhs3.tambahMatkul(mk3);
       
       mhs4.tambahMatkul(mk2);
       mhs4.tambahMatkul(mk3);

       mhs5.tambahMatkul(mk3);

        // TODO: Modifikasi program anda sebelumnya agar berkas ini bisa berjalan baik.

        // cetak mhs 1
        System.out.println("mhs1: " + mhs1);
        /* output yang diharapkan:
        mhs1: Hallo, saya Burhan, saya mengambil 1 mata kuliah dengan total 4 sks
        */

        // cetak mhs 2
        System.out.println("mhs2: " + mhs2);
        /* output yang diharapkan:
        mhs2: Hallo, saya Burung Hantu, saya mengambil 2 mata kuliah dengan total 7 sks
        */

        // cetak mhs 3
        System.out.println("mhs3: " + mhs3);
        /* output yang diharapkan:
        mhs3: Hallo, saya Kak BurHan, saya mengambil 3 mata kuliah dengan total 10 sks
        */

        // cetak mhs 4
        System.out.println("mhs4: " + mhs4);
        /* output yang diharapkan:
        mhs4: Hallo, saya Dek DePe, saya mengambil 2 mata kuliah dengan total 6 sks
        */

        // cetak mhs 5
        System.out.println("mhs5: " + mhs5);
        /* output yang diharapkan:
        mhs5: Hallo, saya Bang PeWe, saya mengambil 1 mata kuliah dengan total 3 sks
        */

        // Apakah anda masih punya waktu?
        // bila masih ada waktu, mungkin anda berminat membuat unit test dari 
        // fungsi2 baru yang dimodifikasi atau dibuat?
        // Disiplin dalam menerapkan pola mengerjaan yang baik, 
        // bisa bermanfaat untuk kemudian hari (soal kemudian) :D
    }
}
