import java.util.ArrayList;
import java.util.List;

public class MataKuliah {
    private String namaMatkul;
    private String kode;
    private int sks;

    public MataKuliah(String namaMataKuliah, String kodeMataKuliah, int sksMataKuliah) {
        this.namaMatkul = namaMataKuliah;
        this.kode = kodeMataKuliah;
        this.sks = sksMataKuliah;
    }

    public String getNamaMatkul(){
        return namaMatkul;
    }

    public String getKode(){
        return kode;
    }

    public int getSks() {
        return sks;
    }
}
