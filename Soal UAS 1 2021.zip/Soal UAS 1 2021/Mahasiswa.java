import java.util.ArrayList;
import java.util.List;

public class Mahasiswa {
    private String nama;
    private String npm;
    private List<MataKuliah> daftarMatkul;
    
    public Mahasiswa (String namaMataKuliah, String kodeMataKuliah) {
        this.nama = namaMataKuliah;
        this.npm = kodeMataKuliah;
        this.daftarMatkul = new ArrayList<>();
    }

    public void tambahMatkul(MataKuliah mk){
        daftarMatkul.add(mk);
    }

    public String getNama() {
        return nama;
    }

    public String getNpm() {
        return npm;
    }

    public int getTotalMatkul(){
        return daftarMatkul.size();
    }

    public int getJumlahSks(){
        int jumlah =0;
        for(MataKuliah mk : daftarMatkul){
            jumlah += mk.getSks();
        }
        return jumlah;
    }

    @Override
    public String toString() {
        return "Hallo, saya " + nama + ", saya mengambil " + getTotalMatkul() + " mata kuliah dengan total " + getJumlahSks() + " sks";
    }
}
